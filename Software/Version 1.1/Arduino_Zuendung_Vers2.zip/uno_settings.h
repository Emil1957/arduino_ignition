// 3 Pins are used for the sensors
// Pin 2 (on UNO): Hall sensor on 
// Pin 15: Coil 1 (redirected analog pin)
// Pin 16: Coil 2 (redirected analog pin)
const uint8_t CAM_SENSOR = 2;  // note this is interrupt 0 on UNO
// adding digital pins
// call analog pins 0 to 5 as Pin 14 to Pin 19 and they will work like digital ones.
const uint8_t COIL1 = A1;//  pin for 1st coil, A1=15 on UNO, A1=19 on Pro Micro
const uint8_t COIL2 = A2; // pin for 2nd coil, A2=16 on ONO, A2=20 on Pro Micro
const uint8_t LED1 = A3; // pin for LED to control ignition for coil 1
const uint8_t LED1 = A4; // pin for LED to control ignition for coil 2
