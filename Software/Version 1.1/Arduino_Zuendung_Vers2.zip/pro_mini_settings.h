const uint8_t CAM_SENSOR = 2;  // note this is Interrupt0
uint8_t TXPIN = 6; // pin for TX to serial LCD (if used)

// adding digital pins
// call analog pins and they will work like digital ones.
const uint8_t COIL1 = A0;//  pin for 1st coil, 
const uint8_t COIL2 = A1; // pin for 2nd coil
const uint8_t LED1 = A2; // pin for LED to control ignition for coil 1
const uint8_t LED2 = A3; // pin for LED to control ignition for coil 2

// variables for rotary switsch (for setting the ignition curve)
const uint8_t ROTARYSWITCH_BIT1  = 9;
const uint8_t ROTARYSWITCH_BIT2  = 8;
const uint8_t ROTARYSWITCH_BIT4  = 7;
const uint8_t ROTARYSWITCH_BIT8  = 6;

