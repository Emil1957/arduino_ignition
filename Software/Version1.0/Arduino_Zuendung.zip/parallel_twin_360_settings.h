const uint8_t NO_OF_CYLINDERS = 2;
const uint16_t MIN_USHALFROT_ENG = 1000; // for table data calculation = 30000 rpm
const uint16_t MIN_ALLOWED_USHALFROT_ENG = 3000; // 3000 red line: Max RPM = 10000
const uint32_t MAX_ALLOWED_USHALFROT_ENG = 200000; // if half rot is higher: engine too slow to start (=300 RPM)

const uint16_t MAX_USHALFROT_ENG = 38000; // MIN RPM = 789 RPM for tabular calculation
const uint16_t USHALFROT_INCR_ENG = 500; // time increment for calculating tabular values

const uint8_t TABLE_SIZE = ( MAX_USHALFROT_ENG - MIN_USHALFROT_ENG ) / USHALFROT_INCR_ENG + 1; // no of items in time/delay table
const uint8_t MAX_TABLE_INDEX = TABLE_SIZE - 1;


/* Possible disk types 
 For a 360° parallel twin "half shaped" vane (Steuerscheibe in German) on the cam shaft 
       |-\
       |  \
       +   |
       |  /
       |-/
       
       
Then we have one signals for each cylinders per revolution (rising flank for one cylinder, falling flank for the other)

The disk type must be considered when calculation revolution time

*/


const uint8_t NO_OF_CURVES = 9;// we have 9 ignition curves with different characteristics
const uint8_t NO_OF_POINTS_PER_CURVE = 4; // each curve is defined by 4 points (pairs of RPM/advance angle)

// For the ignition curves we store RPM/100 instead of RPM to save memory (we can use uint8_t instead of int)
// IMPORTANT: These are RPMs of the crankshaft (Kurbelwelle in German), but the hall sensor is attached to the camshaft (Nockenwelle in German)
// which rotates at half the RPM (=twice the time) of the crankshaft. We will have to consider this (see below)

// Important: Curve data are only example data here!
const uint8_t CURVE_DATA[ NO_OF_CURVES * NO_OF_POINTS_PER_CURVE ][ 2 ] = {
  {10, 2}, // 1000 RPM, 2 deg advance
  {30, 25},
  {37, 28},
  {60, 32}, // end of curve #1
  {11, 8}, // start of curce #2
  {19, 11},
  {40, 31},
  {48, 34}, // end of curce #2
  {11, 8}, // start of curce #3
  {15, 11},
  {32, 31},
  {39, 34}, // end of curve #3
  {11, 8}, // start of curce #4
  {19, 11},
  {41, 33},
  {47, 36}, // end of curve #4
  {11, 8}, // start of curce #5
  {15, 11},
  {32, 33},
  {41, 36}, // end of curve #5
  {11, 8}, // start of curce #6
  {32, 31},
  {42, 37},
  {50, 39}, // end of curve #6
  {10, 2}, // start of curce #7
  {30, 25},
  {44, 31},
  {60, 39}, // end of curve #7
  {10, 1}, // start of curce #8
  {20, 20},
  {30, 29},
  {58, 40}, // end of curve #8
  {10, 1}, // start of curce #9
  {23, 26},
  {34, 36},
  {48, 40} // end of curve #9
};

uint32_t timeForHalfRotationEngine( uint8_t coilNo, uint32_t hallDifference )
// Calculate time for a half rotation of the engine from the "hallDifference" (=time between two adjanced hall signals)
// Depends on the used vane geometry (Steuerscheiben-Geometrie) and the current cylinder/coil
// For a 360° prallel twin we don't have to distinguish between cylinder/coil 1 or 2
{
  uint32_t result;
  result := hallDifference >> 1; // = hallDifference / 2, hallDifference is time for half rotation of the cam(!), half rotation time of engine is half of it
  return result;    
}



