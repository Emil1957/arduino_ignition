const uint8_t NO_OF_CYLINDERS = 2;
const uint16_t MIN_USHALFROT_ENG = 1000; // for table data calculation = 30000 rpm
const uint16_t MIN_ALLOWED_USHALFROT_ENG = 3150; // red line: Max RPM = 9500
const uint32_t MAX_ALLOWED_USHALFROT_ENG = 200000; // if half rot is higher: engine too slow to start (=300 RPM)

const uint16_t MAX_USHALFROT_ENG = 38000; // MIN RPM = 789 RPM for tabular calculation
const uint16_t USHALFROT_INCR_ENG = 500; // time increment for calculating tabular values

const uint8_t TABLE_SIZE = ( MAX_USHALFROT_ENG - MIN_USHALFROT_ENG ) / USHALFROT_INCR_ENG + 1; // no. of items in time/delay table
const uint8_t MAX_TABLE_INDEX = TABLE_SIZE - 1;

/* Disk type for Ducati motor 
Vane is 135° "moon shape" (as 270° ignition difference on the crank shaft)
*/

const uint8_t NO_OF_CURVES = 1;// we have 1 ignition curve
const uint8_t NO_OF_POINTS_PER_CURVE = 9; // each curve is defined by 9 points (pairs of RPM/advance angle)

// For the ignition curves we store RPM/100 instead of RPM to save memory (we can use uint8_t instead of int)
// IMPORTANT: These are RPMs of the crankshaft (Kurbelwelle in German), but the hall sensor is attached to the camshaft (Nockenwelle in German)
// which rotates at half the RPM (=twice the time) of the crankshaft. We will have to consider this (see below)
const uint8_t CURVE_DATA[ NO_OF_CURVES * NO_OF_POINTS_PER_CURVE ][ 2 ] = {
{14, 6 },
{20, 20 },
{25, 27 },
{30, 30 },
{38, 33 },
{55, 35 },
{76, 36 },
{83, 37 },
{90, 39 }
};

uint32_t timeForHalfRotationEngine( uint8_t coilNo, uint32_t hallDifference )
{
// Important: When calling this routine, the coil no has already been modified
  uint32_t result;
  uint8_t prevCoilNo;

// Get previous coil no.  
  switch ( coilNo )
  {
    case 1: 
    { 
      prevCoilNo = 2;
      break;
    }
    case 2:
    {
      prevCoilNo = 1;
      break;
    }
  }
    
  switch ( prevCoilNo )
  {
    case 1: 
    {
      result = ( hallDifference<<1 ) / 3;// = hallDifference*3/5
      break;
    }

    case 2: 
    {
      result = ( hallDifference<<1 ) / 5; // = hallDifference*2/5
      break;
    }
  }
  return result;    
}


